//
//  CollectionViewCell.swift
//  How_to_use_JSON
//
//  Created by Abhishek Verma on 13/12/17.
//  Copyright © 2017 SWIFT HUB. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Rating: UILabel!
    @IBOutlet weak var DirectorName: UILabel!
    @IBOutlet weak var ID: UILabel!
    @IBOutlet weak var NAME: UILabel!
}
